package org.eclipse.paho.sample.mqttclient;

public enum Mode {
	PUB, SUB;

}
