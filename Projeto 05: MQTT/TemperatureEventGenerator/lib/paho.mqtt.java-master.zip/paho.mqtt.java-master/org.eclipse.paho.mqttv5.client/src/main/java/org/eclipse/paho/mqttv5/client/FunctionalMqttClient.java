package org.eclipse.paho.mqttv5.client;

@FunctionalInterface
public interface FunctionalMqttClient {
	int operation(int a, int b);

}
