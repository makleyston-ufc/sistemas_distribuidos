package org.eclipse.paho.mqttv5.client;

public interface MqttClientInterface {
	
	String getClientId();
	
	String getServerURI();

}
