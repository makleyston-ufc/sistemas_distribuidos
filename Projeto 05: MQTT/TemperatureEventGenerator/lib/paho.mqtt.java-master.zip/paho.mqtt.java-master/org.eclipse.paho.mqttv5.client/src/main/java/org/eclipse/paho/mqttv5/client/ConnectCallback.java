package org.eclipse.paho.mqttv5.client;

public interface ConnectCallback {

}
