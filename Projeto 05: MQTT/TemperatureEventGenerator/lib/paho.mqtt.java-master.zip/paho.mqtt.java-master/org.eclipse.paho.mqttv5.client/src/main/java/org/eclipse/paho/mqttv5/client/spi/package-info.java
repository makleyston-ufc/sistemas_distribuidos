/**
 * This package defines extensible service interfaces.
 *
 * @author Maik Scheibler
 */
package org.eclipse.paho.mqttv5.client.spi;
